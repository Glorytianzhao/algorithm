var AEVTAPP = (function () {
    var bpmDomain = window.location.protocol + '//' + window.location.hostname + (window.location.port ? ':' + window.location.port : '');//请求后端接口
    var fieldEnum = {
        level: '告警级别',
        modelname: '模型名称',
        host: '主机',
        description: '描述',
        sourcename: '告警源名称',
        sourcetype: '告警源类型',
        env: '环境',
        application: '应用',
        cluster: '集群',
        service: '服务',
        biz: '业务',
        modelid: '模型id',
        rulename: '规则名称',
        targetname: '告警对象',
        metrickey: '监控指标',
        check: '检查项',
        value: '统计值',
        ip: 'IP',
        metricname: '指标名称',
        timestamp: '告警时间',
        messagetype: '类型',
        group: '分组字段',
        searchcontent: '搜索内容',
        logsource: '日志分组',
        timefield: '时间字段',
        messagesource: '告警消息来源',
        baseline_value: '基线值',
        rate_of_change: '变化率',
        threshold: '阈值',
        time_range: '时间范围',
        //Zabbix 告警消息
        triggername: "触发器名称",
        eventid: "告警事件ID",
        triggerurl: "触发器URL",
        triggerstatus: "触发器状态",
        alert_value: "真实值",
        alert_group_name: "告警组",
        ruletype: "监控类型",
        checkname: "指标名称",
        // JKB告警消息
        task_groups: "任务组",
        task_name: "任务名称",
        task_type: "监控任务类型",
        task_summary: "监控项目摘要",
        msg_id: "告警消息ID",
        task_user_id: "任务创建用户ID",
        task_id: "监控项目ID",
        server_id: "服务器ID",
        device_label: "设备名称",
        deviceid: "设备ID",
        monitor_lable: "监测点名称",
        monitorid: "监测点ID",
        //dola
        groupfieldkey: '分组字段',
        groupfieldvalue: '分组字段值',
        anomaly_type: '异常类型',
        pattern: '算法聚合的模式',
        rule_id: '规则id'
    }
    var logFields = {
        _cw_biz: '业务',
        _cw_app: '应用',
        _cw_log_type: '服务',
        _cw_host_ip: '主机',
        _cw_message: '日志原始内容',
    }
    //1、级别，2、description，3、modelname, 4、targertname, 5、check,  6、告警源，7、告警次数，8、更新时间。
    var fieldOrderEnum = ['level', 'description', 'modelname', 'targertname', 'check', 'sourcename', 'sourcetype']
    //不需要显示的字段
    var disableFields = ['status', 'id', 'alert_message_id', 'alert_title', 'appkey', 'recovered', 'target_id', 'target_type',
        'alerttime', 'dimensions', 'doemtargetname', 'judgebegintime', 'metrictargetname', 'ruleid', 'sendbegintime', 'updatetime', 'message_level']
    var alarmSourceConfig = {
        kafka: 'eventWeb/images/alarmSource/kafka.svg',
        restapi: 'eventWeb/images/alarmSource/restapi.svg',
        zabbix: 'eventWeb/images/alarmSource/ZABBIX.svg',
        tsb: 'eventWeb/images/alarmSource/tsb.svg',
        jkb: 'eventWeb/images/alarmSource/jkb.svg',
        prometheus: 'eventWeb/images/alarmSource/prometheus.svg',
    }
    var defaultConfig = {
        bpmDomain: bpmDomain,
        nacosDomain: window.location.origin + "/gateway/portal/api/v1/webConfig?productNo=event",
        monitorNacosDomain: window.location.origin + "/gateway/portal/api/v1/webConfig?productNo=monitor",
        fetchTimeOut: 60 * 1000,//请求超时
        loggerFlag: false,//日志是否开启
        defaultTheme: "dark",//默认主题色 light dark
        localStoreType: 'localStorage',//本地存储配置
        eventPrefix: 'aevt-',//事件管理器事件名称前缀
        isCheckAuth: false, // 是否开启权限校验
        PATH_PREFIX: '/event',
        API_PREFIX: '/gateway/event',
        ROUTE_PREFIX: '/algorithm',
        defaultRoute: '/algorithm/type',
        project: "aevt",
        refreshToken: 1000, // 刷新权限 0 不刷新
        eventAuthApi: '/api/v1/auth?module=event',
        isAlgorithm: 1, //是否是算法模式，1是算法，0是普通模式
        fieldEnum: fieldEnum,
        fieldOrderEnum: fieldOrderEnum,
        logFields: logFields,
        disableFields: disableFields,
        isNacosDomain: true,
        alarmSourceConfig: alarmSourceConfig,
        dosmConfig: { // dosm 配置
            viewPage: "#/dosm/allWorkOrder/allWorkOrderDetailShow",
            create: "#/dosm/myWorkOrder/create",
            workOrder: true,
        },
        svgEnum: alarmSourceConfig
    }
    return defaultConfig;
})();
